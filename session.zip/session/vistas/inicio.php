<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Inicio de sesión</title>
    <link rel="shortcut icon" href="#">
    <link rel="stylesheet" href="../main.css">
</head>
<body>
    <form action="" method="POST">
        <?php
            if(isset($errorLogin)){
                echo $errorLogin;
            }
        ?>
        <p class="center"><h2>Inicio de sesión</h2></p>
        <p>Correo: <br>
        <input type="text" name="correo" placeholder="Ingresa tu correo" ></p>
        <p>Contraseña: <br>
        <input type="password" name="password" placeholder="Ingresa tu contraseña"></p>
        <br/>
        <p class="center"><input type="submit" value="Entrar"></p>
        <p class="center"><a href="form_cambio_contra.php">¿Olvidaste tu contraseña?</a></p>
    </form>
    
</body>
</html>